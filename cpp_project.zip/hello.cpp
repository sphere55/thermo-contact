#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World! from C++ & MSYS2 GCC 15.2.0 😎" << endl;

    int a = 10, b = 20;
    int sum = a + b;          // 여기 브레이크포인트 걸어보세요
    cout << "sum = " << sum << endl;

    return 0;
}