// hello.c 내용 이렇게 바꾸기
#include <stdio.h>

int main() {
    printf("Hello, World! MSYS2 GCC 15.2.0 test success!\n");
    return 0;
}
